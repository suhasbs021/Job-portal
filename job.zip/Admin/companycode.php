<?php
session_start();
require 'index.php';

if(isset($_POST['save_company']))
{
    $companyid = mysqli_real_escape_string($con, $_POST['companyid']);
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $address = mysqli_real_escape_string($con, $_POST['address']);
    $contactno = mysqli_real_escape_string($con, $_POST['contactno']);

    $query = "INSERT INTO tblcompany (companyid	,name	,address,	contactno) VALUES ('$companyid','$name','$address','$contactno')";

    $query_run = mysqli_query($con, $query);
    if($query_run)
    {
        $_SESSION['message'] = "Company Created Successfully";
        header("Location: addcompany.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "Company Not Created";
        header("Location: addcompany.php");
        exit(0);
    }
}

?>